<?php
// Include database connection
include('connection.php');

// Start session if needed
session_start();

// Check if the user is an admin
// Add your admin check logic here

// Fetch shipped orders from the database
$sql = "SELECT orders.id AS order_id, orders.user_id, orders.order_date, orders.orderStatus, 
               order_items.product_id, order_items.quantity 
        FROM orders 
        JOIN order_items ON orders.id = order_items.order_id 
        WHERE orders.orderStatus = 'Shipped'"; // Adjust the condition based on your database structure

$result = $con->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    echo "<h1>Shipped Orders</h1>";
    echo "<table border='1'>
            <tr>
                <th>Order ID</th>
                <th>User ID</th>
                <th>Product ID</th>
                <th>Quantity</th>
                <th>Order Date</th>
                <th>Order Status</th>
            </tr>";

    while($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row["order_id"]. "</td>
                <td>" . $row["user_id"]. "</td>
                <td>" . $row["product_id"]. "</td>
                <td>" . $row["quantity"]. "</td>
                <td>" . $row["order_date"]. "</td>
                <td>" . $row["orderStatus"]. "</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "No shipped orders found.";
}

$con->close();
?>
