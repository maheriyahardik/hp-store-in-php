<footer>
        <div class="footer">
            <div class="container">
                <div class="row">
                    <!-- Logo Section -->
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                        <img class="logo1" src="images/logo1.png" alt="Logo"/>
                    </div>
                    <!-- Contact Information -->
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                        <h3>Contact Us</h3>
                        <ul class="conta">
                            <li>
                                HP Inc.<br>
                                1501 Page Mill Road<br>
                                Palo Alto, CA 94304-1112<br>
                                USA<br>
                                Phone: +1 (650) 857-1501<br><br>
                               
                            </li>
                        </ul>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                        <h3>Contact Us</h3>
                        <ul class="conta">
                            <li>
                            <strong>India:</strong><br>
                                1. Address: 1st Floor, A - 10, Vishal Enclave, Rajouri Garden, New Delhi, Delhi 110027, India HP World<br>
                                2. Address: SCO- 146-147, Sector 9C, Chandigarh, 160009, India HP World<br>
                                3. Address: Shop No - 3, New Mahavir Nagar, Near Giani Ice Cream, New Delhi, Delhi 110018, India<br>
                                Website: <a href="https://www.hp.com">www.hp.com</a>
                            </li>
                        </ul>
                    </div>
                    <!-- Subscribe Form -->
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                    </div>
                </div>
            </div>
            <!-- About HP World -->
            <div class="copyright">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <p>About HP World<br>
                               Established in India on November 8, 1988, HP India is one of the largest and most diverse sites for HP outside of the US. One of the largest technology providers in India, HP has helped power India's most critical installations and empower people with technology in everyday life.<br>
                               <a href="https://www.hp.com/in-en/shop/">Visit HP Store</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- End Footer Section -->

    <!-- Javascript files -->
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery-3.0.0.min.js"></script>
    <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="js/custom.js"></script>
</body>
</html>