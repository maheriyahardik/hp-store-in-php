
<?php
  // Database connection
  include "connection.php";
   // Start session and get user_id
   session_start();
   $user_id = isset($_SESSION['user']) ; // Ensure user is set in the session
   if ($user_id === 0) {
      // Redirect to login page if user is not logged in
      header("Location: login.php");
      exit;
   }
// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
   $name = trim($_POST['Name']);
   $email = trim($_POST['Email']);
   $phone = trim($_POST['Phone_Number']);
   $message = trim($_POST['Message']);

   // Validate inputs
   $errors = [];
   if (empty($name)) {
      $errors[] = "Name is required.";
   }
   if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $errors[] = "Invalid email format.";
   }
   if (!preg_match("/^[0-9]{10}$/", $phone)) {
      $errors[] = "Invalid phone number.";
   }
   if (empty($message)) {
      $errors[] = "Message is required.";
   }

   if (empty($errors)) {
     // Prepare and execute the SQL statement
      $stmt = $con->prepare("INSERT INTO contacts (name, email, phone_number, message, user_id) VALUES (?, ?, ?, ?, ?)");
      $stmt->bind_param("ssssi", $name, $email, $phone, $message, $user_id);

      if ($stmt->execute()) {
         echo "<p>Message sent successfully!</p>";
      } else {
         echo "<p>Error: " . $stmt->error . "</p>";
      }
      $stmt->close();
   } else {
      foreach ($errors as $error) {
         echo "<p class='error'>$error</p>";
      }
   }

   $con->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Contact Form</title>
   <style>
      /* General styles for body and main layout */
      body.main-layout {
         font-family: Arial, sans-serif;
         background-color: #f0f0f0;
         margin: 0;
         padding: 0;
      }

      .inner_posituong {
         /* Your specific styling for inner position */
      }

      .computer_page {
         /* Your specific styling for computer_page */
      }

      /* Styles for contact form */
      .contact {
         padding: 20px;
      }

      .container {
         max-width: 960px;
         margin: 0 auto;
         background-color: #fff;
         padding: 20px;
         border-radius: 8px;
         box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      }

      .titlepage h2 {
         text-align: center;
         color: #007bff; /* Primary color for headings */
         font-size: 28px;
         margin-bottom: 20px;
      }

      .main_form .row {
         margin-bottom: 15px;
      }

      .main_form input[type="text"],
      .main_form input[type="email"],
      .main_form textarea {
         width: 100%;
         padding: 10px;
         margin-bottom: 10px;
         border: 1px solid #ccc;
         border-radius: 4px;
         box-sizing: border-box;
         font-size: 16px;
      }

      .main_form textarea {
         height: 150px;
         resize: vertical;
      }

      .send_btn {
         background-color: #007bff; /* Primary button color */
         color: #fff;
         padding: 12px 20px;
         border: none;
         border-radius: 4px;
         cursor: pointer;
         font-size: 18px;
         transition: background-color 0.3s ease;
      }

      .send_btn:hover {
         background-color: #0056b3; /* Darker shade on hover */
      }

      .send_btn:disabled {
         background-color: #ccc; /* Disable color */
         cursor: not-allowed;
      }

      .back-to-home {
         display: inline-block;
         margin-top: 10px;
         color: #007bff; /* Link color */
         text-decoration: none;
         font-size: 16px;
         transition: color 0.3s ease;
      }

      .back-to-home:hover {
         color: #0056b3; /* Darker shade on hover */
      }

      .error {
         color: red;
         margin-bottom: 10px;
         display: none;
      }
   </style>
</head>
<body class="main-layout inner_posituong computer_page">

<div class="contact">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <div class="titlepage">
               <h2>Contact Now</h2>
            </div>
         </div>
      </div>
      <div class="row">
         <div class="col-md-10 offset-md-1">
   
            <form id="contactForm" class="main_form" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
               <div class="row">
                  <div class="col-md-12">
                     <input class="contactus" placeholder="Name" type="text" name="Name" required> 
                  </div>
                  <div class="col-md-12">
                     <input class="contactus" placeholder="Email" type="email" name="Email" required> 
                  </div>
                  <div class="col-md-12">
                     <input class="contactus" placeholder="Phone Number" type="text" name="Phone_Number" required>                          
                  </div>
                  <div class="col-md-12">
                     <textarea class="textarea" placeholder="Message" name="Message" required></textarea>
                  </div>
                  <div class="col-md-12">
                     <button class="send_btn" type="submit">Send</button>
                  </div>
               </div>
               <a href="index.php" class="back-to-home">Back to Home</a>
            </form>
         </div>
      </div>
   </div>
</div>

<!-- JavaScript files-->
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/jquery-3.0.0.min.js"></script>
<!-- Sidebar -->
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/custom.js"></script>

<script>
document.getElementById('contactForm').addEventListener('submit', function(event) {
   let isValid = true;
   let errors = [];

   const name = document.getElementsByName('Name')[0].value.trim();
   const email = document.getElementsByName('Email')[0].value.trim();
   const phone = document.getElementsByName('Phone_Number')[0].value.trim();
   const message = document.getElementsByName('Message')[0].value.trim();

   // Validate name
   if (name === '') {
      isValid = false;
      errors.push('Name is required.');
   }

   // Validate email
   const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
   if (!emailPattern.test(email)) {
      isValid = false;
      errors.push('Invalid email format.');
   }

   // Validate phone number (10 digits)
   const phonePattern = /^[0-9]{10}$/;
   if (!phonePattern.test(phone)) {
      isValid = false;
      errors.push('Invalid phone number.');
   }

   // Validate message
   if (message === '') {
      isValid = false;
      errors.push('Message is required.');
   }

   // Display errors if any
   const errorContainer = document.createElement('div');
   errorContainer.className = 'error';
   errors.forEach(function(error) {
      const errorElem = document.createElement('p');
      errorElem.textContent = error;
      errorContainer.appendChild(errorElem);
   });

   if (!isValid) {
      event.preventDefault();
      // Remove existing errors and append new ones
      const form = document.getElementById('contactForm');
      const existingErrorContainer = form.querySelector('.error');
      if (existingErrorContainer) {
         existingErrorContainer.remove();
      }
      form.prepend(errorContainer);
   }
});
</script>
</body>
</html>
