
<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hp";
$con = new mysqli($servername, $username, $password, $dbname);
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}


// Assuming user_id is stored in session
$user_id = intval($_SESSION['user']);

if ($user_id === 0) {
    // Redirect to login page if user is not logged in
    header("Location: login.php");
    exit;
}
// Handle update quantity
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['update_cart'])) {
        foreach ($_POST['quantity'] as $product_id => $quantity) {
            // Validate and sanitize input if needed
            $quantity = intval($quantity); // Convert to integer for safety
            $product_id = intval($product_id);

            // Update quantity in cart table
            $update_sql = "UPDATE carts SET quantity = $quantity WHERE product_id = $product_id AND user_id = $user_id";
            $con->query($update_sql);
        }
    } elseif (isset($_POST['remove_product'])) {
        $product_id = intval($_POST['product_id']);
        // Remove the product from the cart
        $remove_sql = "DELETE FROM carts WHERE product_id = $product_id AND user_id = $user_id";
        $con->query($remove_sql);
    } 
}

// Retrieve products in cart for the logged-in user
$sql = "SELECT p.id, p.name, p.price, c.quantity FROM products p JOIN carts c ON p.id = c.product_id WHERE c.user_id = $user_id";
$result = $con->query($sql);

// Initialize total price
$total_price = 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
<?php include "menu1.php";?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Cart</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        margin: 20px;
        background-color: #f9f9f9;
    }
    .cart-container {
        max-width: 900px;
        margin: auto;
        border: 1px solid #ddd;
        border-radius: 8px;
        background-color: #fff;
        padding: 20px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    .cart-container h2 {
        font-size: 28px;
        margin-bottom: 15px;
        color: #333;
    }
    .cart-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    .cart-table th, .cart-table td {
        border: 1px solid #ddd;
        padding: 12px;
        text-align: left;
    }
    .cart-table th {
        background-color: #f2f2f2;
        font-weight: bold;
    }
    .cart-table td {
        background-color: #fafafa;
    }
    .cart-table input[type="number"] {
        width: 60px;
        padding: 5px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }
    .cart-total {
        margin-top: 20px;
        font-size: 20px;
        font-weight: bold;
    }
    .cart-actions {
        margin-top: 20px;
        text-align: right;
    }
    .cart-actions button, .cart-actions a {
        display: inline-block;
        margin-left: 10px;
        text-decoration: none;
        padding: 10px 20px;
        border-radius: 5px;
        color: #fff;
        background-color: #007bff;
        transition: background-color 0.3s ease;
        border: none;
        cursor: pointer;
    }
    .cart-actions button:hover, .cart-actions a:hover {
        background-color: #0056b3;
    }
    .back-to-home {
        display: inline-block;
        margin-top: 20px;
        text-decoration: none;
        padding: 10px 20px;
        background-color: #555;
        color: #fff;
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }
    .back-to-home:hover {
        background-color: #333;
    }
    .btn-contact-shipping:hover {
        background-color: #218838;
    }
    </style>
</head>
<body>
    <div class="cart-container">
        <h2>My Cart</h2>

        <?php if ($result->num_rows > 0): ?>
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <table class="cart-table">
                    <tr>
                        <th>Product Name</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Action</th>
                    </tr>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <?php
                            $product_id = $row['id'];
                            $product_name = $row['name'];
                            $price = $row['price'];
                            $quantity = $row['quantity'];
                            $total_per_item = $price * $quantity;
                            $total_price += $total_per_item;
                        ?>
                        <tr>
                            <td><?php echo $product_name; ?></td>
                            <td><?php echo $price; ?></td>
                            <td><input type="number" name="quantity[<?php echo $product_id; ?>]" value="<?php echo $quantity; ?>" min="1" max="100"></td>
                            <td><?php echo number_format($total_per_item, 2); ?></td>
                            <td>
                                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" style="display:inline;">
                                    <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                                    <button type="submit" name="remove_product">Remove</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    <tr class="cart-total">
                        <td colspan="4" align="right"><strong>Total:</strong></td>
                        <td><?php echo number_format($total_price, 2); ?></td>
                    </tr>
                </table>

                <div class="cart-actions">
                    <button type="submit" name="update_cart">Update Cart</button>
                    <a href="checkout.php">Add Address</a>
                    <a href="payment-method.php">Payment</a>
                </div>
            </form>
        <?php else: ?>
            <p>Your cart is empty.</p>
        <?php endif; ?>
        <a href="index.php" class="back-to-home">Back to Home</a>
        <a href="laptop_view.php" class="back-to-home">Contact Shipping</a>
    </div>
</body>
</html>

<?php
$con->close();
?>
