<!-- <!DOCTYPE html>
<html lang="en">
  <!-- body -->
  <body class="main-layout inner_posituong computer_page">
   <!-- loader  -->
   <div class="loader_bg">
   <div class="loader"><img src="images/loading.gif" alt="#" /></div>
   </div>
   <!-- end loader -->
   <?php include "menu.php";?>
   <!-- header -->
   <?php include "header.php"; ?>
      <div class="laptop">
         <div class="container">
            <div class="row">
               <div class="col-md-6">
                  <div class="titlepage">
                     <p>Every Computer and laptop</p>
                     <h2>Up to 40% off !</h2>
                     <p>Computer</p>
                     <a class="read_more" href="everylc.php">Shop Now</a>
                     <a class="read_more" href="addcart.php">Add to cart</a>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="laptop_box">
                     <figure><img src="images/pc.png" alt="#"/></figure>
                  </div>
               </div>
            </div>
         </div>
      </div>
      </div>
      <div class="laptop">
         <div class="container">
            <div class="row">
               <div class="col-md-6">
                  <div class="titlepage">
                     <p>
                     Tackle all your daily tasks with an affordable desktop that comes packed with all the features you need.
                     </p>
                     <h2>Starting from:  ₹39,499</h2>
                     <!-- <a class="read_more" href="#">Shop Now</a> --> 
                     <a class="read_more" href="HP_60.5_cm.php">Shop Now</a>
                     <a class="read_more" href="addcart.php">Add to cart</a>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="laptop_box">
                     <figure><img src="images/computer1.jpg" alt="#"/></figure>
                     <h1></h1><h1>
                    <h1>Essentials Home</h1></h1>
                  </div>
               </div>
            </div>
         </div>
      </div>
      </div>
      <div class="laptop">
         <div class="container">
            <div class="row">
               <div class="col-md-6">
                  <div class="titlepage">
                     <p>
                     
                     Create, connect and share with a versatile, beautifully designed PC that lets you express your creativity.
                     </p>
                     <h2>Starting from:  ₹109,199</h2>
                     <!-- <a class="read_more" href="#">Shop Now</a> -->
                     <a class="read_more" href="HP_Pavilion_Desktop.php">Shop Now</a>
                     <a class="read_more" href="addcart.php">Add to cart</a>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="laptop_box">
                     <figure><img src="images/computer2.jpg" alt="#"/></figure>
                     <h1>Pavilion</h1>
                  </div>
               </div>
            </div>
         </div>
      </div>
      </div>
      <div class="laptop">
         <div class="container">
            <div class="row">
               <div class="col-md-6">
                  <div class="titlepage">
                     <p>
                     Become unstoppable. Geared with the latest graphics and processor, easy upgradability, and advanced cooling, for your 
                     best gaming experience.
                     </p>
                     <h2>Starting from:  ₹286,200</h2>
                     <a class="read_more" href="HP_OMEN_45L.php">Shop Now</a>
                     <a class="read_more" href="addcart.php">Add to cart</a>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="laptop_box">
                     <figure><img src="images/computer3.jpg" alt="#"/></figure>
                     <h1></h1><h1>
                    <h1>OMEN Gaming</h1></h1>
                  </div>
               </div>
            </div>
         </div>
      </div>
      </div>
      <div class="laptop">
      <div class="container">
         <div class="row">
            <div class="col-md-6">
               <div class="titlepage">
                  <p>
                  Power and performance for a premium entertainment, gaming and multitasking experience.
                  </p>
                  <h2>Starting from:  ₹97,200</h2>
                  <!-- <a class="read_more" href="#">Shop Now</a> -->
                  <a class="read_more" href="HP_Victus_5L.php">Shop Now</a>
                  <a class="read_more" href="addcart.php">Add to cart</a>
               </div>
            </div>
            <div class="col-md-6">
               <div class="laptop_box">
                  <figure><img src="images/computer4.jpg" alt="#"/></figure>
                <h1>VICTUS</h1>
               </div>
            </div>
         </div>
      </div>
   </div>
      <!-- end laptop  section -->
      <!--  footer -->
      <?php include "footer.php";?>
      <!-- end  footer -->
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <!-- sidebar -->
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>
   </body>
</html>
 -->
