<!-- end products -->
<div  class="products">
         <div class="container"> 
            <div class="row">
               <div class="col-md-4">
                  <div class="titlepage">
                     <a class="read_more" href="#">Our products</a>
                     <div class="col-md-12">
                     <a class="read_more" href="computer.php">Views Computer</a>
                     <a class="read_more" href="laptop.php">Views Leptop</a>
                     </div>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-12">
                  <div class="our_products" href="products.php">
                     <div class="row">
                        <div class="col-md-4 margin_bottom1">
                           <div class="product_box">
                              <figure><img src="images/product1.png" alt="#"/></figure>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <a class="read_more" href="HP_68.6_cm.php">computer</a>
                              <a class="read_more" href="addcart.php">Add to Cart</a>
                           </div>
                        </div>
                        <div class="col-md-4 margin_bottom1">
                           <div class="product_box">
                              <figure><img src="images/product2.png" alt="#"/></figure>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <a class="read_more" href="Elitebook_Ultra_35.6.php">leptop</a>
                              <a class="read_more" href="addcart.php">Add to Cart</a>
                           </div>
                        </div>
                        <div class="col-md-4">
                           <div class="product_box">
                              <figure><img src="images/printer.jpg" alt="#"/></figure>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <a class="read_more" href="Deskjet_2332_Colour.php">printer</a>
                              <a class="read_more" href="addcart.php">Add to Cart</a>
                           </div>
                        </div>
                        <div class="col-md-4 margin_bottom1">
                           <div class="product_box">
                              <figure><img src="images/product4.png" alt="#"/></figure>
                              <a class="read_more" href="HP_Black_Bluetooth.php">Speakers</a>
                              <a class="read_more" href="addcart.php">Add to Cart</a>
                           </div>
                        </div>
                        <div class="col-md-4 margin_bottom1">
                           <div class="product_box">
                              <figure><img src="images/product5.png" alt="#"/></figure>
                              <a class="read_more" href="HP_Laptop_Charger.php">Charger</a>
                              <a class="read_more" href="addcart.php">Add to Cart</a>
                           </div>
                        </div>
                        <div class="col-md-4 margin_bottom1">
                           <div class="product_box">
                              <figure><img src="images/product6.png" alt="#"/></figure>
                              <h1></h1>
                              <h1></h1>
                              <a class="read_more" href="ssd.php">SDD</a>
                              <a class="read_more" href="addcart.php">Add to Cart</a>
                           </div>
                        </div>
                        <div class="col-md-4">
                           <div class="product_box">
                              <figure><img src="images/product7.png" alt="#"/></figure>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <a class="read_more" href="product.php">Ram</a>
                              <a class="read_more" href="addcart.php">Add to Cart</a>
                           </div>
                        </div>
                        <div class="col-md-4">
                           <div class="product_box">
                              <figure><img src="images/product8.png" alt="#"/></figure>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <a class="read_more" href="Bettery.php">Bettery</a>
                              <a class="read_more" href="addcart.php">Add to Cart</a>
                           </div>
                        </div>
                        <div class="col-md-4">
                           <div class="product_box">
                              <figure><img src="images/product9.png" alt="#"/></figure>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <h1></h1>
                              <a class="read_more" href="HP_818w_128GB.php">Drive</a>
                              <a class="read_more" href="addcart.php">Add to Cart</a>
                           </div>
                        </div> 
                        <div class="col-md-12">
                           <a class="read_more" href="login.php">See More</a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   <!-- end products -->
 