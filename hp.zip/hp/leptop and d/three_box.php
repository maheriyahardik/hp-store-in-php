<div class="three_box">
      <div class="container">
         <div class="row">
            <div class="col-md-4">
               <div class="box_text">
                  <i><img src="images/thr.png" alt="#"/></i>
                  <h1>computer</h1>
                  <h1></h1>
                  <p>A computer is a machine that can be programmed to automatically carry out sequences of arithmetic or logical operations 
                     (computation). Modern digital electronic computers can perform generic sets of operations known as programs. 
                     These programs enable computers to perform a wide range of tasks. 
                  </p>
               </div>
            </div>
            <div class="col-md-4">
               <div class="box_text">
                  <i><img src="images/thr1.png" alt="#"/></i>
                  <h1></h1>
                  <h1></h1>
                  <h1></h1>
                  <h1>Laptop</h1>
                  <p>Laptops are designed to be portable computers. They are smaller and lighter than desktops. The name connotes the user's
                     ability to put the computer in their lap while they use it. .I capabilities that will become more important in the
                     future with improved performance that you can feel today. 
                  </p>
               </div>
            </div>
            <div class="col-md-4">
               <div class="box_text">
                  <i><img src="images/thr2.jpg" alt="#"/></i>
                  <h1></h1>
                     <h1></h1>
                     <h1></h1>
                     <h1></h1>
                     <h1></h1>
                     <h1></h1>
                     <h1></h1>
                     <h1></h1>
                     <h1></h1>
                     <h1></h1>
                     <h1></h1>
                     <h1></h1> 
                     <h1></h1> 
                     <h1></h1>
                  <h1>Keyboard</h1>
                  <p> computer keyboard is an input device that allows a person to enter letters , numbers,and other symbols (together, called characters) into
                     a computer. Using a keyboard is often called typing.  ixing a malfunctioning laptop keyboard is a straightforward step-by-step
                      perform a process that just requires tools . 
                  </p>
               </div>
            </div>
         </div>
      </div>
   </div>