<section class="banner_main">
   <div id="banner1" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
         <li data-target="#banner1" data-slide-to="0" class="active"></li>
         <li data-target="#banner1" data-slide-to="1"></li>
         <li data-target="#banner1" data-slide-to="2"></li>
         <li data-target="#banner1" data-slide-to="3"></li>
         <li data-target="#banner1" data-slide-to="4"></li>
      </ol>
      <div class="carousel-inner">
         <div class="carousel-item active">
            <div class="container">
               <div class="carousel-caption">
                  <div class="row">
                     <div class="col-md-6">
                        <div class="text-bg">
                           <span>hp product</span>
                           <h1>Accessories</h1>
                           <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration 
                              in some form, by injected humour.</p>
                           <!-- <a href="buy.html" class="btn">Buy Now</a> -->
                           <!-- <a href="contact.html">Contact</a> -->
                           <!-- <a href="login.html">Login Now</a> -->
                        </div>
                     </div>
                     <div class="col-md-6">
                        <div class="text_img">
                           <figure><img src="images/pct.png" alt="Product Image"/></figure>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="carousel-item">
            <div class="container">
               <div class="carousel-caption">
                  <div class="row">
                     <div class="col-md-6">
                        <div class="text-bg">
                           <span>hp product</span>
                           <h1>Accessories</h1>
                           <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour.</p>
                           <!-- <a href="login.html">Buy Now</a> -->
                           <!-- <a href="contact.html">Contact</a> -->
                        </div>
                     </div>
                     <div class="col-md-6">
                        <div class="text_img">
                           <figure><img src="images/pct1.jpg" alt="Product Image"/></figure>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="carousel-item">
            <div class="container">
               <div class="carousel-caption">
                  <div class="row">
                     <div class="col-md-6">
                        <div class="text-bg">
                           <span>hp product</span>
                           <h1>Accessories</h1>
                           <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour.</p>
                           <!-- <a href="login.html">Buy Now</a> -->
                           <!-- <a href="contact.html">Contact</a> -->
                        </div>
                     </div>
                     <div class="col-md-6">
                        <div class="text_img">
                           <figure><img src="images/pct2.png" alt="Product Image"/></figure>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="carousel-item">
            <div class="container">
               <div class="carousel-caption">
                  <div class="row">
                     <div class="col-md-6">
                        <div class="text-bg">
                           <span>hp product</span>
                           <h1>Accessories</h1>
                           <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in 
                              some form, by injected humour.</p>
                           <!-- <a href="login.html">Buy Now</a> -->
                           <!-- <a href="contact.html">Contact</a> -->
                        </div>
                     </div>
                     <div class="col-md-6">
                        <div class="text_img">
                           <figure><img src="images/pct3.png" alt="Product Image"/></figure>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="carousel-item">
            <div class="container">
               <div class="carousel-caption">
                  <div class="row">
                     <div class="col-md-6">
                        <div class="text-bg">
                           <span>hp product</span>
                           <h1>Accessories</h1>
                           <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in 
                              some form, by injected humour.</p>
                           <!-- <a href="login.html">Buy Now</a> -->
                           <!-- <a href="contact.html">Contact</a> -->
                        </div>
                     </div>
                     <div class="col-md-6">
                        <div class="text_img">
                           <figure><img src="images/pct4.png" alt="Product Image"/></figure>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <a class="carousel-control-prev" href="#banner1" role="button" data-slide="prev">
         <i class="fa fa-chevron-left" aria-hidden="true"></i>
      </a>
      <a class="carousel-control-next" href="#banner1" role="button" data-slide="next">
         <i class="fa fa-chevron-right" aria-hidden="true"></i>
      </a>
   </div>
</section>
<!-- end banner -->