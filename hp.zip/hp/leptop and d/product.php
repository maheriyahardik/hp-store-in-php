<!DOCTYPE html>
<html lang="en">
      <!-- body -->
      <body class="main-layout inner_posituong computer_page">
      <!-- loader  -->
      <div class="loader_bg">
      <div class="loader"><img src="images/loading.gif" alt="#" /></div>
      </div>
      <!-- loader -->
      <?php include "menu.php";?>
      <!-- end loader -->
      <?php include "header.php"; ?>
      <!-- products -->
      <?php include "products.php"; ?>
      <!-- end products -->
      <!--  footer -->
      <?php include "footer.php"; ?>
      <!-- end footer -->
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <!-- sidebar -->
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>
   </body>
</html>

