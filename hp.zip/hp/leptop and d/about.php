<?php include "menu.php";?>
      <!-- end header inner -->
      <div class="about">
         <div class="container">
            <div class="row d_flex">
               <div class="col-md-5">
                  <div class="titlepage">
                     <h2>About Us</h2>
                     <p>We are a technology company born of the belief that companies should do more than just make a profit. They should make 
                        theworld a better place.Our efforts in climate action, human rights, and digital equity prove that we are doing 
                        everything in our power to make it so. With over 80 years of actions that prove our intentions, we have the confidence
                        to envision a world where innovation drives extraordinary contributions to humanity.And our technology a product and
                        service portfolio of personal systems, printers, and 3D printing solutions – was created to inspire this meaningful 
                        progress.We know that thoughtful ideas can come from anyone, anywhere, at any time.And all it takes is one to change
                         the world.
                     </p>
                     <a class="read_more" href="laptop.php">laptop Read More</a>
                     <a class="read_more" href="laptop.php">computer Read More</a>
                     <a class="read_more" href="addcart.php">Add to Cart</a>
                     <a class="read_more" href="login.php">Login Now</a>
                  </div>
               </div>
               <div class="col-md-7">
                  <div class="about_img">
                     <figure><img src="images/about.jpg" alt="#"/></figure>
                  </div>
               </div>
            </div>
         </div>
      </div>
      </div>
      <!-- end about section -->
      <!--  footer -->
<?php include "footer.php";?>
    
