<?php
session_start();
include "connection.php";

// Pagination variables
$entries_per_page = 5;
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$start = ($page - 1) * $entries_per_page;

// Fetch users from database
$search = isset($_GET['search']) ? $_GET['search'] : '';
$query = "SELECT * FROM users";
if (!empty($search)) {
    if (is_numeric($search)) {
        $query .= " WHERE id = $search";
    } else {
        $query .= " WHERE username LIKE '%$search%' OR name LIKE '%$search%' OR email LIKE '%$search%' OR mobile_number LIKE '%$search%'";
    }
}
$query .= " LIMIT $start, $entries_per_page";

$result = mysqli_query($con, $query);

// Count total users (for pagination)
$count_query = "SELECT COUNT(*) AS total_count FROM users";
if (!empty($search)) {
    if (is_numeric($search)) {
        $count_query .= " WHERE id = $search";
    } else {
        $count_query .= " WHERE username LIKE '%$search%' OR name LIKE '%$search%' OR email LIKE '%$search%' OR mobile_number LIKE '%$search%'";
    }
}

$count_result = mysqli_query($con, $count_query);
$count_row = mysqli_fetch_assoc($count_result);
$total_users = $count_row['total_count'];

// Delete user
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $delete_query = "DELETE FROM users WHERE id = $delete_id";
    mysqli_query($con, $delete_query);
    header("Location: manage_users.php?page=$page&search=$search");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
            padding: 8px;
        }
        .pagination {
            margin-top: 10px;
        }
        .pagination a {
            padding: 5px 10px;
            margin-right: 5px;
            text-decoration: none;
            background-color: #f2f2f2;
            color: black;
            border: 1px solid #ccc;
        }
        .pagination a.active {
            background-color: #4CAF50;
            color: white;
        }
        .pagination a:hover:not(.active) {
            background-color: #ddd;
        }
        .back-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .back-btn:hover {
            background-color: #0056b3;
        }
        .delete-btn {
            padding: 5px 10px;
            background-color: #ff4d4d;
            color: white;
            text-decoration: none;
            border-radius: 3px;
        }
        .delete-btn:hover {
            background-color: #ff1a1a;
        }
    </style>
</head>
<body>
    <h2>User List</h2>

    <!-- Search form -->
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="GET">
        Search by ID: <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>">
        <button type="submit">Search</button>
    </form>

    <!-- User table -->
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Name</th>
                <th>Email</th>
                <th>Mobile Number</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['username']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo $row['mobile_number']; ?></td>
                    <td><a href="manage_users.php?delete_id=<?php echo $row['id']; ?>&page=<?php echo $page; ?>&search=<?php echo $search; ?>" class="delete-btn">Delete</a></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>

    <!-- Pagination -->
    <?php if ($total_users > $entries_per_page) { ?>
        <div class="pagination">
            <?php
            $total_pages = ceil($total_users / $entries_per_page);
            $prev = $page - 1;
            $next = $page + 1;

            if ($page > 1) {
                echo "<a href='manage_users.php?page=$prev&search=$search'>Previous</a>";
            }

            for ($i = 1; $i <= $total_pages; $i++) {
                $active = ($page == $i) ? "active" : "";
                echo "<a href='manage_users.php?page=$i&search=$search' class='$active'>$i</a>";
            }

            if ($page < $total_pages) {
                echo "<a href='manage_users.php?page=$next&search=$search'>Next</a>";
            }
            ?>
        </div>
    <?php } ?>
    <a href="admin-home.php" class="back-btn">Back to Home Page</a>

</body>
</html>
