   <?php include "menu.php";?>
   <!-- footer -->
   <?php include "three_box.php"; ?>
   <?php include "footer.php"; ?>
   <!-- end footer -->
  