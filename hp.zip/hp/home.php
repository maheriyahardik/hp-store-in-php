 
   <!-- customer -->
  <div class="customer">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="titlepage">
                     <h2>Customer Review</h2>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-12">
                  <div id="myCarousel" class="carousel slide customer_Carousel " data-ride="carousel">
                     <ol class="carousel-indicators">
                        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                        <li data-target="#myCarousel" data-slide-to="1"></li>
                        <li data-target="#myCarousel" data-slide-to="2"></li>
                     </ol>
                     <div class="carousel-inner">
                        <div class="carousel-item active">
                           <div class="container">
                              <div class="carousel-caption ">
                                 <div class="row">
                                    <div class="col-md-9 offset-md-3">
                                       <div class="test_box">
                                          <i><img src="images/cos.png" alt="l"/></i>
                                          <h4>HP a reputable company</h4>
                                          <p>Fortune magazine named HP one of the World's Most Admired Companies in 2010,
                                              placing it No. 2 in the computer industry and No. 32 overall in its list of the top 50. 
                                              This year in the computer industry HP was ranked No.</p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="carousel-item">
                           <div class="container">
                              <div class="carousel-caption">
                                 <div class="row">
                                    <div class="col-md-9 offset-md-3">
                                       <div class="test_box">
                                          <i><img src="images/cos.png" alt="#"/></i>
                                          <h4>Martin Reynolds</h4>
                                          <p> star as none is not an option, brought an envy printer and instant ink 
                                             ,they had to change printer as only printing half pages eventually as support are
                                              useless,new one arrived and still same problem ,again support are useless ,there stock 
                                              answer is to change ink cartridge or try different things that didn't work before,many times . 
                                              Don't buy hp it's simple, problem ongoing for months maybe 12 or more</p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="carousel-item">
                           <div class="container">
                              <div class="carousel-caption">
                                 <div class="row">
                                    <div class="col-md-9 offset-md-3">
                                       <div class="test_box">
                                          <i><img src="images/cos.png" alt="#"/></i>
                                          <h4>Alexander P</h4>
                                          <p>I own Elitebook for my daily work 50-60 hours a week, it is 2.5 years old machine already 
                                             visited official service 2 times due to warranty issue.
                                             Now, there is electricity shock on the computer whenever somebody touches me if I am working.
                                             CS team tried to escalate the case but local representatives only follow official guidline,
                                             "go and check with nearest service since warranty is over' What?! a computer is 5 months after
                                              warranty expired and they cannot even make diagnostic on such a safety issue. Avoid ! I would 
                                              spare this one to another brand. They better focus on product not FB posts and such.</p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
                     <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                     <span class="sr-only">Previous</span>
                     </a>
                     <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
                     <span class="carousel-control-next-icon" aria-hidden="true"></span>
                     <span class="sr-only">Next</span>
                     </a>
                  </div>
               </div>
            </div>
         </div>
      </div>
       <!-- end customer -->
  
   