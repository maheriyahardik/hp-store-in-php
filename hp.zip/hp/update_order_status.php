<?php
session_start();


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hp";

// Create connection
$con = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $order_id = $_POST['order_id'];
    $order_status = $_POST['order_status'];

    // Update order status
    $sql = "UPDATE orders SET orderStatus = ? WHERE id = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("si", $order_status, $order_id);
    if ($stmt->execute()) {
        $_SESSION['success'] = "Order status updated successfully.";
    } else {
        $_SESSION['error'] = "Failed to update order status.";
    }

    $stmt->close();
}

$con->close();

// Redirect back to the admin order management page
header("Location: track-order.php");
exit;
?>
